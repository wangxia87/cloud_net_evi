#!/usr/bin/python
#print('__init__')
#print('__init__.__name__', __name__)
#print('__init__.__package__', __package__)
def main():
    print '__init__.main()'
